//
//  ViewController.swift
//  UISample
//
//  Created by youngmin joo on 2018. 2. 1..
//  Copyright © 2018년 youngmin joo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var selectedBtn: UIButton?
    var selectedBtnList: [UIButton] = []
    var centerTextLb: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let bgImg: UIImage = UIImage(named: "bg")!
        
//        let bgImgView: UIImageView = UIImageView(frame: view.bounds)
//        bgImgView.image = #imageLiteral(resourceName: "bg")
//        bgImgView.backgroundColor = #colorLiteral(red: 1, green: 0, blue: 0.8580412269, alpha: 1)
//        bgImgView.contentMode = UIViewContentMode.scaleAspectFill
//        view.addSubview(bgImgView)
//
//        let coverView: UIView = UIView(frame: bgImgView.bounds)
//
//        coverView.backgroundColor = .black
//        coverView.alpha = 0.4
//        bgImgView.addSubview(coverView)
//
//        //레이블
//        let titleLb: UILabel = UILabel(frame: CGRect(x: 0, y: 100, width: view.frame.size.width, height: 150))
//        titleLb.text = "UI Test View"
//        titleLb.textColor = UIColor.darkGray
//        titleLb.font = UIFont.systemFont(ofSize: 45)
//        titleLb.textAlignment = .center
//        view.addSubview(titleLb)
//
//
//        centerTextLb = UILabel(frame: CGRect(x: 20, y: view.frame.size.height/2 - 150, width: view.frame.size.width - 40, height: 300))
//        centerTextLb.text =
//        """
//        중간에 표시되는 텍스트 길게 작성해볼까요?
//        여러줄을 표시할수 있습니다,
//        이렇게~~~
//        """
//        centerTextLb.textColor = .blue
//        centerTextLb.font = UIFont.systemFont(ofSize: 30)
//        centerTextLb.numberOfLines = 0
//        centerTextLb.lineBreakMode = .byCharWrapping
//        view.addSubview(centerTextLb)
//
//
//        let logoBtn: UIButton = UIButton()
//        logoBtn.frame = CGRect(x: 0, y: 25, width: 400, height: 50)
//        logoBtn.setTitle("왼쪽", for: .normal)
//
//        logoBtn.setTitleColor(.black, for: .normal)
//        logoBtn.setTitleColor(.blue, for: .highlighted)
//        logoBtn.setTitleColor(.red, for: .selected)
//        logoBtn.tag = 1
//        logoBtn.backgroundColor = .white
//        logoBtn.addTarget(self, action:
//            #selector(self.logoEventTouchUpInside(_:)), for: .touchUpInside)
//        view.addSubview(logoBtn)
//
//        let logoBtn2: UIButton = UIButton()
//        logoBtn2.frame = CGRect(x: 0, y: 80, width: 400, height: 50)
//        logoBtn2.setTitle("중간", for: .normal)
//
//        logoBtn2.setTitleColor(.black, for: .normal)
//        logoBtn2.setTitleColor(.blue, for: .highlighted)
//        logoBtn2.setTitleColor(.red, for: .selected)
//        logoBtn2.tag = 2
//        logoBtn2.backgroundColor = .white
//        logoBtn2.addTarget(self, action:
//            #selector(self.logoEventTouchUpInside(_:)), for: .touchUpInside)
//        view.addSubview(logoBtn2)
//
//        let logoBtn3: UIButton = UIButton()
//        logoBtn3.frame = CGRect(x: 0, y: 140, width: 400, height: 50)
//        logoBtn3.setTitle("아래", for: .normal)
//
//        logoBtn3.setTitleColor(.black, for: .normal)
//        logoBtn3.setTitleColor(.blue, for: .highlighted)
//        logoBtn3.setTitleColor(.red, for: .selected)
//        logoBtn3.tag = 3
//        logoBtn3.backgroundColor = .white
//        logoBtn3.addTarget(self, action:
//            #selector(self.logoEventTouchUpInside(_:)), for: .touchUpInside)
//        view.addSubview(logoBtn3)
//
//        let resultBtn: UIButton = UIButton()
//        resultBtn.frame = CGRect(x: 0, y: 240, width: 400, height: 50)
//        resultBtn.setTitle("결과", for: .normal)
//
//        resultBtn.setTitleColor(.black, for: .normal)
//
//        resultBtn.backgroundColor = .red
//        resultBtn.addTarget(self, action:
//            #selector(self.result(_:)), for: .touchUpInside)
//        view.addSubview(resultBtn)
        
        
        
        let myView:ProfileView = ProfileView(frame: CGRect(x: 30, y: 30, width: 300, height: 80))
        myView.setTitle("안녕")
        myView.setImage(named: "sosi.jpeg")
        
        self.view.addSubview(myView)
        
        
        let myView2 = ProfileView(frame:CGRect(x: 30 , y: 100, width: 300, height: 100))
        myView2.setTitle("시작이야")
        myView2.setImage(named: "logo.jpg")
//        myView2.addTarget(self, action: #selector( ), for: .touchUpInside)
        
        self.view.addSubview(myView2)
        
        
    }

    
    @objc func logoEventTouchUpInside(_ sender:UIButton)
    {
        if sender.isSelected == false
        {
            sender.isSelected = true
            selectedBtnList.append(sender)
        }else
        {
            let index:Int = selectedBtnList.index(of: sender)!
            selectedBtnList.remove(at: index)
            sender.isSelected = false
        }
    }
    
    @objc func result(_ sender:UIButton)
    {
//        guard let sBtn = selectedBtn else { return }
//
//        centerTextLb.text = String(sBtn.tag)
        
        var resultStr = ""
        for n in selectedBtnList
        {
            resultStr += String(n.tag)
        }
        centerTextLb.text = resultStr
        
    }
    

}

