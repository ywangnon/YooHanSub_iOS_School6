//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import ReactorKit
import RxCocoa
import RxSwift

final class ___VARIABLE_reactorKitModuleName___Reactor: Reactor {
  typealias Action = NoAction
  
  struct State {
//  <#State Properties#>
  }
  
  let initialState: State
  
  init() {
    initialState = State()
  }
}
