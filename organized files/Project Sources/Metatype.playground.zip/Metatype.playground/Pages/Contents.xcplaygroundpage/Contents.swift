/*:
 # Metatype
 1. **Basic**
 2. **TestCode**
 3. **TypeCheck**
 4. **Usage**
 
 by Giftbot
*/
//: [Next](@next)
