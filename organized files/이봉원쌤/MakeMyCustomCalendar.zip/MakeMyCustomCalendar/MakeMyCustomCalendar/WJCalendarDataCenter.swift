//
//  WJCalendarDataCenter.swift
//  MakeMyCustomCalendar
//
//  Created by youngmin joo on 2017. 11. 8..
//  Copyright © 2017년 youngmin joo. All rights reserved.
//

import Foundation

enum WeekDay:Int
{
    case Sun=0,Mon,Tue,Wed,Thu,Fri,Sat
    
    var name:String{
        switch self {
        case .Sun:
            return "Sun"
        case .Mon:
            return "Mon"
        case .Tue:
            return "Tue"
        case .Wed:
            return "Wed"
        case .Thu:
            return "Thu"
        case .Fri:
            return "Fri"
        case .Sat:
            return "Sat"
        }
    }
}

class WJCalendarManger
{
    
    class func nextMonth(with dateModel:WJCalendarDataModel) -> Date
    {
        let calendarIns = Calendar(identifier: .gregorian)
        var newComponets = DateComponents()
        newComponets.year = dateModel.year
        newComponets.month = dateModel.month + 1
        newComponets.day = dateModel.day
        
        if let nextDate = calendarIns.date(from: newComponets)
        {
            return nextDate
        }else
        {
            return Date()
        }

    }
    
    class func previousMonth(with nowDate:Date) -> Date?
    {
        let calendarIns = Calendar(identifier: .gregorian)
        var addComponets = DateComponents()
        addComponets.month =  -1
        
        guard let newDate =  calendarIns.date(byAdding: addComponets, to: nowDate) else { return nil}
        
        return newDate
    }
    
    
}


struct WJCalendarDataModel {
    
    var year:Int
    var month:Int
    var day:Int
    
    var startWeekOfMonth:WeekDay
    var lastDayOfMonth:Int
    
    
    private let calendarIns = Calendar(identifier: .gregorian)
    init?(date:Date)
    {
        var components = calendarIns.dateComponents([.year, .month, .day], from: date)
        year = components.year ?? 0
        month = components.month ?? 0        
        day = components.day ?? 0
        components.day = 1
        
        //각 년월의 1일인 date
        guard let firstDayDate = calendarIns.date(from: components) else { return nil }
        var weekDayCompo = calendarIns.dateComponents([.weekday], from: firstDayDate)
        
        startWeekOfMonth = WeekDay.init(rawValue: weekDayCompo.weekday! - 1)!
        
        var addComponets = DateComponents()
        addComponets.month = 1
        addComponets.day =  -1

        guard let lastDayDate =  calendarIns.date(byAdding: addComponets, to: firstDayDate) else { return nil}
        lastDayOfMonth = calendarIns.dateComponents([.day], from: lastDayDate).day ?? 1
        
        
    }
    
    
    func newDate(of day:Int) -> Date?
    {
        var newComponets = DateComponents()
        newComponets.year = self.year
        newComponets.month = self.month
        newComponets.day = day
        
        return calendarIns.date(from: newComponets)
        
    }
    
}





