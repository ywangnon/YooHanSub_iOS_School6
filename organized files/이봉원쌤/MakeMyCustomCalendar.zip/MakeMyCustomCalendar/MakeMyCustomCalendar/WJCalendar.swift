//
//  WJCalendar.swift
//  MakeMyCustomCalendar
//
//  Created by youngmin joo on 2017. 11. 8..
//  Copyright © 2017년 youngmin joo. All rights reserved.
//

import UIKit

@objc protocol WJCalendarDelegate {
    @objc optional func calendar(_ calendar:WJCalendar, didSelectedDate:Date?)
    
    @objc optional func cellData(for date:Date) -> String?
}

class WJCalendar: UIView  {

    var delegate:WJCalendarDelegate?
    
    var year:Int?
    var month:Int?
    
    //Mark : - Property
    var date:Date?{
        willSet{
            calendarData = WJCalendarDataModel(date: newValue!)
            year = calendarData?.year
            month = calendarData?.month
            contentsView.reloadData()
        }
    }
    
    private var calendarData:WJCalendarDataModel?
    
    //Mark : - Private Property
    private var contentsView:UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        
       let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: 100, height: 100), collectionViewLayout: layout)
        //collectionView 속성 추가 가능
        collection.backgroundColor = .black
        return collection
    }()
    
    private let cellIdentifier = "Cell"
    
    
    //Mark : - init
    override func awakeFromNib() {
        setUpUI()
        updateLayout()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
        updateLayout()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    func updateNextMonth()
    {
        date = WJCalendarManger.nextMonth(with: calendarData!)
    }
    
    
    func updatePreMonth()
    {
       date = WJCalendarManger.previousMonth(with: date!)
    }
    
    
    
    //Mark : - private Method
    //UI 관련 setup이 필요한 경우
    private func setUpUI()
    {
        //collectionView setup
        self.addSubview(contentsView)
        contentsView.delegate = self
        contentsView.dataSource = self
        contentsView.register(CustomCell.self, forCellWithReuseIdentifier: cellIdentifier)
        
    }
    //UI Autolayout 적용
    private func updateLayout()
    {
        contentsView.constraint(targetView: self, topConstant: 0, bottomConstant: 0, leftConstant: 0, rightConstant:0)
        
//        contentsView.translatesAutoresizingMaskIntoConstraints = false
//
//        contentsView.topAnchor.constraint(equalTo: topAnchor).isActive = true
//        contentsView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
//        contentsView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
//        contentsView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        
//        contentsView.topAnchor.constraint(equalTo: self.topAnchor, constant: 0)
    }
    

}
//collectionView Delegate
extension WJCalendar:UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 7
        }else
        {
            if let calendarData = calendarData
            {
                return calendarData.lastDayOfMonth + calendarData.startWeekOfMonth.rawValue
            }else
            {
                return 0
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! CustomCell
        
        cell.initUI()
        cell.backgroundColor = .white
        if indexPath.section == 0 {
           cell.titleLb.text = WeekDay(rawValue: indexPath.item)?.name
            cell.isUserInteractionEnabled = false
        }else
        {
            let changedIndex = indexPath.item - calendarData!.startWeekOfMonth.rawValue
            if changedIndex >= 0
            {
                let day = changedIndex + 1
                cell.titleLb.text = "\(day)"
                cell.date = calendarData?.newDate(of: day)
                
                cell.data = delegate?.cellData?(for: cell.date!)
            }
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! CustomCell
        
        delegate?.calendar?(self, didSelectedDate: cell.date)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (collectionView.frame.size.width - 8)  / 7
        
        if indexPath.section == 0
        {
           return CGSize(width: width, height: 30)
        }else
        {
//            let height = (collectionView.frame.size.height - 30) / 5
            return CGSize(width: width, height: width)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    }
    
    
}

class CustomCell:UICollectionViewCell{
    
    var titleLb:UILabel = {
        let lb = UILabel()
        lb.textAlignment = .center
        return lb
    }()
    
    var data:String?{
        didSet{
            backgroundColor = .red
        }
    }
    
    var date:Date?
    
    func initUI()
    {
        titleLb.text = ""
        date = nil
        self.isUserInteractionEnabled = true
        backgroundColor = .white
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    private func setUpUI()
    {
        //collectionView setup
        self.addSubview(titleLb)
        updateLayout()
    }
    
    private func updateLayout()
    {
        
        titleLb.constraint(targetView: self, topConstant: 0, bottomConstant: 0, leftConstant: 0, rightConstant: 0)
        
//        titleLb.translatesAutoresizingMaskIntoConstraints = false
//        titleLb.topAnchor.constraint(equalTo: topAnchor).isActive = true
//        titleLb.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
//        titleLb.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
//        titleLb.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        //        contentsView.topAnchor.constraint(equalTo: self.topAnchor, constant: 0)
//        titleLb.centerXAnchor.constraint(equalTo: self.centerXAnchor)
//        titleLb.centerYAnchor.constraint(equalTo: self.centerYAnchor)
//        titleLb.widthAnchor.constraint(equalTo: self.widthAnchor)
//        titleLb.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.6, constant: 3)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}


extension UIView{
    
    func constraint(targetView:UIView, topConstant:CGFloat?, bottomConstant:CGFloat?, leftConstant:CGFloat?, rightConstant:CGFloat?)
    {
        self.translatesAutoresizingMaskIntoConstraints = false
        
        if let constant = topConstant{
            self.topAnchor.constraint(equalTo: targetView.topAnchor, constant: constant).isActive = true
        }
        if let constant = bottomConstant{
            self.bottomAnchor.constraint(equalTo: targetView.bottomAnchor, constant: constant).isActive = true
        }
        if let constant = leftConstant{
            self.leftAnchor.constraint(equalTo: targetView.leftAnchor, constant: constant).isActive = true
        }
        if let constant = rightConstant{
            self.rightAnchor.constraint(equalTo: targetView.rightAnchor, constant: constant).isActive = true
        }
    }
    
    func constraint(targetView:UIView, widthSize:CGFloat?, heightSize:CGFloat?)
    {
        
    }
}



















