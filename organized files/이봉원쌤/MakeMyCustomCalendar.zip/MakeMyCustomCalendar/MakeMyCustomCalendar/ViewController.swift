//
//  ViewController.swift
//  MakeMyCustomCalendar
//
//  Created by youngmin joo on 2017. 11. 8..
//  Copyright © 2017년 youngmin joo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, WJCalendarDelegate {

    let dates = [Date():"1"]
    
    @IBOutlet weak var yearLb: UILabel!
    @IBOutlet weak var wjcalendar: WJCalendar!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        wjcalendar.date = Date()
        wjcalendar.delegate = self
        monthLb.text = "\(wjcalendar.month!)월"
        yearLb.text = "\(wjcalendar.year!)년"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func calendar(_ calendar: WJCalendar, didSelectedDate: Date?) {
        if let date =  didSelectedDate
        {
            print(date)
        }
    }
    func cellData(for date:Date) -> String?
    {
        if let data = dates[date]
        {
            return data
        }
        return nil
    }
    
    
    @IBOutlet weak var monthLb: UILabel!
    
    @IBAction func previousMonthHandler(_ sender: UIButton) {
        wjcalendar.updatePreMonth()
        monthLb.text = "\(wjcalendar.month!)월"
        yearLb.text = "\(wjcalendar.year!)년"
    }
    
    @IBAction func nextMonthHandler(_ sender: UIButton) {
        wjcalendar.updateNextMonth()
        monthLb.text = "\(wjcalendar.month!)월"
        yearLb.text = "\(wjcalendar.year!)년"
    }
    
    
   

}

enum WeekDayName:Int {
    case Sun, Mon, Tus
    
    var str:String{
        switch self
        {
        case .Sun:
            return "Sun"
        case .Mon:
            return "Mon"
        case .Tus:
            return "Tus"
        }
    }
}






