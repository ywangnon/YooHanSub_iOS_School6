//
//  User.swift
//  FastAPI
//
//  Created by Dabu on 2018. 3. 28..
//  Copyright © 2018년 Dabu. All rights reserved.
//

import Foundation

struct User: Codable {
  
  let username: String
  let email: String
}
