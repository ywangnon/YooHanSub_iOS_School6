//
//  TableViewCell.swift
//  FastAPI
//
//  Created by Dabu on 2018. 3. 28..
//  Copyright © 2018년 Dabu. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
  
  @IBOutlet weak var titleLabel: UILabel!
  @IBOutlet weak var contentLabel: UILabel!
  @IBOutlet weak var contentImageView: UIImageView!
  
  override func awakeFromNib() {
    super.awakeFromNib()
    
  }
  
  func configure(with post: Post) {
    self.titleLabel.text = post.title
    self.contentLabel.text = post.content
//    self.contentImageView.image = UI
  }
  
}
