//
//  PostService.swift
//  FastAPI
//
//  Created by Dabu on 2018. 3. 28..
//  Copyright © 2018년 Dabu. All rights reserved.
//

import Foundation
import Alamofire


struct PostService {
  
  static func postList(completionHandler: @escaping ([Post]) -> Void) {
    
    Alamofire
      .request("https://api.lhy.kr/posts/", method: .get)
      .responseData { response in
        switch response.result {
        case .success(let data):
          // Data -> [Post]
          do {
            let result = try JSONDecoder().decode([Post].self, from: data)
            completionHandler(result)
          } catch {
            print(error)
          }

        case .failure(let error):
          print(error)
        }
      }
  }
}
