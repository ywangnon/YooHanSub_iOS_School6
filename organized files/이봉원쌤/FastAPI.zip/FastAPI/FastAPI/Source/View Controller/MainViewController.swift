

import UIKit

class MainViewController: UIViewController {
  
  @IBOutlet weak private var tableView: UITableView!
  var source: [Post]?
  var refreshControl: UIRefreshControl?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    refreshControl = UIRefreshControl()
    refreshControl?.addTarget(self, action: #selector(refresh(_:)), for: .valueChanged)
    refreshControl?.attributedTitle = NSAttributedString(string: "로딩중..")
    tableView.refreshControl = refreshControl
    
    tableView.register(
      UINib(nibName: "TableViewCell", bundle: nil),
      forCellReuseIdentifier: "TableViewCell"
    )
    fetchData()
  }
  
  @objc private func refresh(_ sender: UIRefreshControl) {
    PostService.postList(completionHandler: { posts in
      self.source = posts
      self.tableView.reloadData()
      sender.endRefreshing()
    })
  }
  
  private func fetchData() {
    PostService.postList(completionHandler: { posts in
      self.source = posts
      self.tableView.reloadData()
    })
  }
  
}

extension MainViewController: UITableViewDataSource {
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return self.source?.count ?? 0
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let postCell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
    let postData = self.source?[indexPath.row]
    postCell.configure(with: postData!)
    return postCell
  }
}

extension MainViewController: UITableViewDelegate {
  
}












