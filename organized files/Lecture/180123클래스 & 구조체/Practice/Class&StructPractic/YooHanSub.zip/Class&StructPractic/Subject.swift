//
//  Subject.swift
//  Class&StructPractic
//
//  Created by Hansub Yoo on 2018. 1. 23..
//  Copyright © 2018년 hansub yoo. All rights reserved.
//

import Foundation

/// 과목 구조체
struct Subject {
    var name: String
    var score: Int
}
