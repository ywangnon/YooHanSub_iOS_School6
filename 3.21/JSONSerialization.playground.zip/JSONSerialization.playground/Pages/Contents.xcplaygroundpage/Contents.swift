/*:
 # JSONSerialization
 
 1. **Creating JSON Data**
 2. **Creating a JSON Object**
 3. **Parsing JSON**
 
 by Giftbot
*/
//: [Next](@next)
