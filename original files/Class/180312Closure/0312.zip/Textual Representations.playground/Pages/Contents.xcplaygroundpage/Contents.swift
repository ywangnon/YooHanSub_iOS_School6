/*:
 # Textual Representations
 1. print, debugPrint, dump
 2. CustomClass Representations
 3. CustomStringConvertible, CustomDebugStringConvertible
 4. LosslessStringConvertible
 by Giftbot
 */
//: [Next](@next)
