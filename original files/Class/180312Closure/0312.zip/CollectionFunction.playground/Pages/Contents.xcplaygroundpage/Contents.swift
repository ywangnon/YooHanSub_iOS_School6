/*:
 # Collection Functions
 1. stride
 2. repeatElement
 3. zip
 4. sequence
 5. etc (enumerated, sorted, reversed)
 
 by Giftbot
 */
//: [Next](@next)
