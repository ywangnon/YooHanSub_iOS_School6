/*:
 # Closure
 
 1. **Closure**
 2. **CaptureList**
 3. **NoEscaping**
 4. **Escaping**
 5. **AutoClosure**
 
 by Giftbot
*/
//: [Next](@next)
