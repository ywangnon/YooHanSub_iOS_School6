/*:
 # Codable
 1. **Basic Codable**
 2. **Nested Codable**
 3. **Nested Keys**
 4. **Codable Extension**
 5. **Handle download data**

 by Giftbot
 
*/
//: [Next](@next)
