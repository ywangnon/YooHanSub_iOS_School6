//
//  AppDelegate.swift
//  URLSessionExample
//
//  Created by giftbot on 2018. 3. 21..
//  Copyright © 2018년 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {
  var window: UIWindow?
}


